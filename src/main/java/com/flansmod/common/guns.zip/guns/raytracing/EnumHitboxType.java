package com.flansmod.common.guns.raytracing;

public enum EnumHitboxType
{
	BODY, HEAD, LEFTARM, RIGHTARM, LEFTITEM, RIGHTITEM
}
